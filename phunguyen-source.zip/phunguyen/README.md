# phunguyen — Auto Clicker cho nông trại Play Together

Ứng dụng Android tự động **chạm / vuốt**, mỗi thao tác có thể **chỉ chạy khi nhìn thấy một hình**.
Nhiều **dự án** riêng biệt, **sao chép – dán** được sang máy khác.

## Build APK

**Cách 1 – Android Studio:** mở thư mục này → chờ Gradle sync → `Build > Build APK(s)`.
Tệp ra ở `app/build/outputs/apk/debug/phunguyen-debug.apk`.

**Cách 2 – GitHub Actions (không cần máy tính mạnh):** đẩy thư mục này lên một repo GitHub,
vào tab *Actions* → *Build APK* → tải artifact `phunguyen-apk`.

Yêu cầu: JDK 17, Android SDK 34. `minSdk` 26 (nhận diện ảnh cần Android 11+).

## Cách dùng

1. Mở app, thêm thao tác (Chạm hoặc Vuốt), đặt thời gian chờ 100 ms – 100 000 ms cho từng thao tác.
2. Bật dịch vụ **phunguyen** trong Cài đặt > Trợ năng.
3. Mở game. Bảng nổi có nút ▶ Bắt đầu và danh sách thao tác. Tick thao tác cần chạy,
   kéo chấm số tới đúng vị trí (Vuốt có 2 chấm: `n` = bắt đầu, `→n` = kết thúc).
4. Bấm 📷 cạnh một thao tác, khoanh vùng hình cần nhận diện → thao tác đó chỉ chạy khi thấy hình,
   không thấy thì bị bỏ qua và chuyển sang thao tác kế tiếp.

## Sao chép dự án sang máy khác

Trong app: **📋 Sao chép** → gửi đoạn chữ qua tin nhắn → trên máy kia mở phunguyen → **📥 Dán**
(hoặc dùng **📤 Chia sẻ**). Đoạn chữ có dạng `PHUNGUYEN1:...` gồm toàn bộ thao tác, thời gian chờ
và cả ảnh nhận diện. Vị trí chấm lưu theo tỷ lệ màn hình nên khớp gần đúng trên máy khác;
nếu lệch thì kéo lại chấm.

## Cấu trúc mã

| Tệp | Vai trò |
|---|---|
| `Model.kt` | Thao tác, dự án, mã hoá sao chép/dán |
| `Store.kt` | Lưu mỗi dự án thành một tệp JSON |
| `Matcher.kt` | Nhận diện ảnh (không cần OpenCV) |
| `CaptureView.kt` | Màn khoanh vùng ảnh mẫu |
| `AutoClickService.kt` | Dịch vụ trợ năng: chấm, bảng nổi, vòng chạy, chụp màn hình |
| `MainActivity.kt` | Giao diện quản lý dự án và thao tác |
