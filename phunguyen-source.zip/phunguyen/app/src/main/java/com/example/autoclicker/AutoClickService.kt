package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class AutoClickService : AccessibilityService() {

    companion object {
        private val COLORS = intArrayOf(
            Color.RED, Color.rgb(0, 150, 0), Color.BLUE,
            Color.rgb(255, 140, 0), Color.MAGENTA, Color.rgb(0, 150, 170)
        )
        private const val SKIP_DELAY_MS = 400L   // chờ khi bỏ qua thao tác (không thấy ảnh); cũng tránh chụp màn hình quá dày
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private class Marker(val view: TextView, val params: LayoutParams)

    private lateinit var wm: WindowManager
    private lateinit var store: ProjectStore
    private lateinit var panelParams: LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private val bg: ExecutorService = Executors.newSingleThreadExecutor()

    private var project = Project()
    private val startMarkers = HashMap<String, Marker>()
    private val endMarkers = HashMap<String, Marker>()
    private var panel: LinearLayout? = null
    private var startBtn: Button? = null

    private var running = false
    private var generation = 0      // tăng mỗi lần bắt đầu/dừng để huỷ các callback cũ
    private var cursor = 0

    private var capturing = false
    private var captureRoot: FrameLayout? = null
    private var captureBmp: Bitmap? = null

    private var lastOrientation = Configuration.ORIENTATION_UNDEFINED

    private val baseFlags = LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS

    // App sửa dự án xong -> nạp lại và vẽ lại chấm + bảng điều khiển
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == ProjectStore.KEY_REV) handler.post { rebuildAll() }
    }

    // ------------------------------------------------------------------ vòng đời

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = ProjectStore(this)
        lastOrientation = resources.configuration.orientation

        panelParams = LayoutParams(
            WRAP, WRAP,
            LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = store.prefs.getInt("panel_x", dp(8))
            y = store.prefs.getInt("panel_y", dp(120))
        }

        rebuildAll()
        store.prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::wm.isInitialized && newConfig.orientation != lastOrientation) {
            lastOrientation = newConfig.orientation
            rebuildAll()   // đặt lại chấm theo tỷ lệ màn hình mới
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        generation++
        handler.removeCallbacksAndMessages(null)
        if (::store.isInitialized) store.prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        if (::wm.isInitialized) removeAllOverlays()
        bg.shutdown()
        super.onDestroy()
    }

    private fun rebuildAll() {
        stopRun()
        removeAllOverlays()
        project = store.active()
        project.actions.forEachIndexed { i, a -> if (a.enabled) addMarkers(a, i) }
        buildPanel()
    }

    private fun removeAllOverlays() {
        finishCapture()
        for (m in startMarkers.values) safeRemove(m.view)
        for (m in endMarkers.values) safeRemove(m.view)
        startMarkers.clear()
        endMarkers.clear()
        panel?.let { safeRemove(it) }
        panel = null
        startBtn = null
    }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // view đã bị gỡ
        }
    }

    // ------------------------------------------------------------------ chấm đánh dấu

    private fun markerFlags() =
        if (running) baseFlags or LayoutParams.FLAG_NOT_TOUCHABLE else baseFlags

    private fun markerAlpha() = if (running) 0.35f else 0.85f

    private fun addMarkers(a: ClickAction, index: Int) {
        addMarker(a, index, false)
        if (a.type == ActionType.SWIPE) addMarker(a, index, true)
    }

    private fun removeMarkers(a: ClickAction) {
        startMarkers.remove(a.id)?.let { safeRemove(it.view) }
        endMarkers.remove(a.id)?.let { safeRemove(it.view) }
    }

    private fun addMarker(a: ClickAction, index: Int, end: Boolean) {
        val map = if (end) endMarkers else startMarkers
        if (map.containsKey(a.id)) return
        val size = dp(44)
        val v = TextView(this).apply {
            text = if (end) "→${index + 1}" else "${index + 1}"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (end) 13f else 16f
            alpha = markerAlpha()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLORS[index % COLORS.size])
                setStroke(dp(2), Color.WHITE)
            }
        }
        val screen = screenSize()
        val p = LayoutParams(
            size, size, LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            markerFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((if (end) a.x2 else a.x1) * screen.x - size / 2f).toInt()
            y = ((if (end) a.y2 else a.y1) * screen.y - size / 2f).toInt()
        }
        v.setOnTouchListener(makeDrag(p) {
            val s = screenSize()
            val fx = ((p.x + size / 2f) / s.x).coerceIn(0f, 1f)
            val fy = ((p.y + size / 2f) / s.y).coerceIn(0f, 1f)
            if (end) {
                a.x2 = fx
                a.y2 = fy
            } else {
                a.x1 = fx
                a.y1 = fy
            }
            store.save(project)
        })
        wm.addView(v, p)
        map[a.id] = Marker(v, p)
    }

    private fun markerCenter(m: Marker?): PointF? {
        val v = m?.view ?: return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return PointF(loc[0] + v.width / 2f, loc[1] + v.height / 2f)
    }

    private fun setOverlaysVisible(visible: Boolean) {
        val vis = if (visible) View.VISIBLE else View.INVISIBLE
        for (m in startMarkers.values) m.view.visibility = vis
        for (m in endMarkers.values) m.view.visibility = vis
        panel?.visibility = vis
    }

    // ------------------------------------------------------------------ bảng điều khiển

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(215, 30, 30, 30))
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = TextView(this).apply {
            text = "☰ ${project.name}"
            setTextColor(Color.LTGRAY)
            textSize = 12f
            setSingleLine(true)
            maxWidth = dp(150)
            setPadding(0, dp(6), dp(12), dp(6))
        }
        handle.setOnTouchListener(makeDrag(panelParams) {
            store.prefs.edit()
                .putInt("panel_x", panelParams.x)
                .putInt("panel_y", panelParams.y)
                .apply()
        })
        val fold = TextView(this).apply {
            text = "▾"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(8), 0, dp(4), 0)
        }
        header.addView(handle)
        header.addView(fold)
        p.addView(header)

        val btn = Button(this).apply {
            text = if (running) "■ Dừng" else "▶ Bắt đầu"
            setOnClickListener { toggleRun() }
        }
        startBtn = btn
        p.addView(btn)

        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (project.actions.isEmpty()) {
            body.addView(TextView(this).apply {
                text = "Chưa có thao tác.\nThêm trong app phunguyen."
                setTextColor(Color.LTGRAY)
                textSize = 12f
            })
        } else {
            project.actions.forEachIndexed { i, a -> body.addView(buildRow(a, i)) }
        }
        // Danh sách dài thì cuộn, tối đa 40% chiều cao màn hình
        body.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxH = (screenSize().y * 0.4f).toInt()
        val scroll = ScrollView(this)
        scroll.addView(body)
        p.addView(scroll, LinearLayout.LayoutParams(WRAP, minOf(body.measuredHeight, maxH)))

        fold.setOnClickListener {
            val show = scroll.visibility != View.VISIBLE
            scroll.visibility = if (show) View.VISIBLE else View.GONE
            fold.text = if (show) "▾" else "▸"
        }

        wm.addView(p, panelParams)
        panel = p
    }

    private fun rebuildPanel() {
        panel?.let { safeRemove(it) }
        panel = null
        startBtn = null
        buildPanel()
    }

    private fun buildRow(a: ClickAction, index: Int): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val shownName = if (a.name.isBlank()) "Thao tác ${index + 1}" else a.name
        val label = "${index + 1}. $shownName" +
            (if (a.type == ActionType.SWIPE) " ↔" else "") +
            (if (a.image != null) " 🖼" else "")
        row.addView(CheckBox(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
            buttonTintList = ColorStateList.valueOf(Color.WHITE)
            isChecked = a.enabled
            setOnCheckedChangeListener { _, on ->
                a.enabled = on
                store.save(project)
                if (on) addMarkers(a, index) else removeMarkers(a)
            }
        })
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            row.addView(TextView(this).apply {
                text = "📷"
                textSize = 18f
                setPadding(dp(10), dp(4), dp(6), dp(4))
                setOnClickListener { startCapture(a) }
            })
        }
        return row
    }

    // ------------------------------------------------------------------ chạy / dừng

    private fun toggleRun() {
        if (running) stopRun() else startRun()
    }

    private fun startRun() {
        if (capturing) return
        if (project.actions.none { it.enabled }) {
            toast("Hãy tick ít nhất một thao tác")
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R &&
            project.actions.any { it.enabled && it.image != null }
        ) {
            toast("Android dưới 11 không nhận diện được ảnh: các thao tác sẽ chạy không kiểm tra ảnh")
        }
        running = true
        generation++
        cursor = 0
        applyRunState()
        handler.post(stepRunnable)
    }

    private fun stopRun() {
        if (!running) return
        running = false
        generation++
        handler.removeCallbacks(stepRunnable)
        applyRunState()
    }

    // Khi đang chạy, các chấm phải "xuyên thấu" để cú chạm tới game bên dưới
    private fun applyRunState() {
        startBtn?.text = if (running) "■ Dừng" else "▶ Bắt đầu"
        for (m in startMarkers.values + endMarkers.values) {
            m.params.flags = markerFlags()
            m.view.alpha = markerAlpha()
            try {
                wm.updateViewLayout(m.view, m.params)
            } catch (e: Exception) {
                // view đã bị gỡ
            }
        }
    }

    private val stepRunnable = Runnable { step() }

    private fun scheduleIfCurrent(gen: Int, delayMs: Long) {
        if (running && gen == generation) {
            handler.removeCallbacks(stepRunnable)
            handler.postDelayed(stepRunnable, delayMs)
        }
    }

    /** Một bước: lấy thao tác đang bật kế tiếp (lặp vòng), kiểm tra ảnh nếu có rồi thực hiện. */
    private fun step() {
        if (!running) return
        val gen = generation
        val list = project.actions.filter { it.enabled }
        if (list.isEmpty()) {
            scheduleIfCurrent(gen, 500L)
            return
        }
        val idx = cursor % list.size
        cursor = idx + 1
        val a = list[idx]

        if (a.image != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            findImage(a) { hit ->
                if (running && gen == generation) {
                    if (hit == null) scheduleIfCurrent(gen, SKIP_DELAY_MS) else perform(a, hit, gen)
                }
            }
        } else {
            perform(a, null, gen)
        }
    }

    private fun perform(a: ClickAction, hit: PointF?, gen: Int) {
        val s = markerCenter(startMarkers[a.id])
        if (s == null) {
            scheduleIfCurrent(gen, SKIP_DELAY_MS)
            return
        }
        val path = Path()
        val duration: Long
        if (a.type == ActionType.SWIPE) {
            val e = markerCenter(endMarkers[a.id])
            if (e == null) {
                scheduleIfCurrent(gen, SKIP_DELAY_MS)
                return
            }
            path.moveTo(s.x, s.y)
            path.lineTo(e.x, e.y)
            duration = a.swipeMs.coerceIn(50L, 10_000L)
        } else {
            val t = if (a.tapOnMatch && hit != null) hit else s
            path.moveTo(t.x, t.y)
            duration = 50L
        }

        // Thời gian chờ tính SAU khi cử chỉ kết thúc
        val after = { scheduleIfCurrent(gen, a.delayMs) }
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                after()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                after()
            }
        }
        val ok = try {
            val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), callback, handler)
        } catch (e: Exception) {
            false
        }
        if (!ok) after()
    }

    // ------------------------------------------------------------------ chụp màn hình / nhận diện ảnh

    /**
     * Chụp màn hình (Android 11+). work chạy trên luồng nền với bitmap phần mềm và phải tự
     * giải phóng nó nếu không trả lại; done chạy trên luồng chính (null nếu thất bại).
     */
    private fun <T> screenshotAsync(work: (Bitmap) -> T?, done: (T?) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            done(null)
            return
        }
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY, bg,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        var out: T? = null
                        val hb = screenshot.hardwareBuffer
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            if (hw != null) {
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                if (soft != null) out = work(soft)
                            }
                        } catch (e: Throwable) {
                            out = null
                        } finally {
                            hb.close()
                        }
                        val result = out
                        handler.post { done(result) }
                    }

                    override fun onFailure(errorCode: Int) {
                        handler.post { done(null) }
                    }
                }
            )
        } catch (e: Exception) {
            done(null)
        }
    }

    private fun findImage(a: ClickAction, done: (PointF?) -> Unit) {
        screenshotAsync<PointF>(
            work = { bmp ->
                val w = bmp.width
                val h = bmp.height
                val scene = Matcher.toCanonGray(bmp)
                bmp.recycle()
                val tpl = TemplateCache.get(a)
                if (tpl == null) null else Matcher.locate(scene, tpl, a.matchPct, w, h)
            },
            done = done
        )
    }

    private fun startCapture(a: ClickAction) {
        if (capturing) return
        stopRun()
        capturing = true
        setOverlaysVisible(false)   // ẩn chấm và bảng để không lọt vào ảnh chụp
        handler.postDelayed({
            screenshotAsync<Bitmap>({ it }) { bmp ->
                if (!capturing) {
                    bmp?.recycle()
                } else if (bmp == null) {
                    finishCapture()
                    toast("Không chụp được màn hình (game có thể chặn chụp màn hình)")
                } else {
                    showCaptureUi(a, bmp)
                }
            }
        }, 350L)
    }

    private fun showCaptureUi(a: ClickAction, bmp: Bitmap) {
        captureBmp = bmp
        val sel = CaptureView(this, bmp)
        val root = FrameLayout(this)
        root.addView(sel, FrameLayout.LayoutParams(MATCH, MATCH))

        val hint = TextView(this).apply {
            text = "Kéo ngón tay để khoanh vùng ảnh cần nhận diện"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            textSize = 14f
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(
            hint,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                .apply { topMargin = dp(40) }
        )

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        bar.addView(Button(this).apply {
            text = "Hủy"
            setOnClickListener { finishCapture() }
        })
        bar.addView(Button(this).apply {
            text = "Lưu ảnh"
            setOnClickListener { saveCapture(a, sel, bmp) }
        })
        root.addView(
            bar,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = dp(48) }
        )

        val p = LayoutParams(
            MATCH, MATCH, LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags, PixelFormat.TRANSLUCENT
        )
        wm.addView(root, p)
        captureRoot = root
    }

    private fun saveCapture(a: ClickAction, sel: CaptureView, bmp: Bitmap) {
        val r = sel.selection()
        if (r == null) {
            toast("Hãy kéo chọn một vùng trước")
            return
        }
        val g = Matcher.cropTemplate(bmp, r.left, r.top, r.right, r.bottom)
        when {
            g == null -> toast("Vùng chọn quá nhỏ")
            g.w > Matcher.MAX_TPL || g.h > Matcher.MAX_TPL -> toast("Vùng chọn quá lớn, hãy khoanh gọn hơn")
            Matcher.contrast(g) < 6f -> toast("Vùng chọn quá đơn sắc, hãy chọn vùng có nhiều chi tiết hơn")
            else -> {
                a.image = Matcher.encode(g)
                store.save(project)
                finishCapture()
                rebuildPanel()
                toast("Đã lưu ảnh nhận diện")
            }
        }
    }

    private fun finishCapture() {
        captureRoot?.let { safeRemove(it) }
        captureRoot = null
        captureBmp?.recycle()
        captureBmp = null
        if (capturing) {
            capturing = false
            setOverlaysVisible(true)
        }
    }

    // ------------------------------------------------------------------ tiện ích

    private fun makeDrag(params: LayoutParams, onUp: (() -> Unit)? = null) =
        object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = params.x
                        sy = params.y
                        tx = e.rawX
                        ty = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = sx + (e.rawX - tx).toInt()
                        params.y = sy + (e.rawY - ty).toInt()
                        try {
                            wm.updateViewLayout(v.rootView, params)
                        } catch (ex: Exception) {
                            // view đã bị gỡ
                        }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onUp?.invoke()
                }
                return true
            }
        }

    @Suppress("DEPRECATION")
    private fun screenSize(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }
}
