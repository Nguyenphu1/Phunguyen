package com.example.autoclicker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

/**
 * Hiển thị ảnh chụp màn hình đã "đóng băng" và cho người dùng kéo chọn một vùng.
 * selection() trả về vùng theo pixel của ảnh chụp.
 */
class CaptureView(context: Context, private val bmp: Bitmap) : View(context) {

    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint().apply { color = Color.argb(130, 0, 0, 0) }
    private val boxPaint = Paint().apply {
        style = Paint.Style.STROKE
        color = Color.YELLOW
        strokeWidth = 3f * context.resources.displayMetrics.density
    }
    private val dst = Rect()

    private var x0 = 0f
    private var y0 = 0f
    private var x1 = 0f
    private var y1 = 0f
    private var has = false

    override fun onDraw(canvas: Canvas) {
        dst.set(0, 0, width, height)
        canvas.drawBitmap(bmp, null, dst, bmpPaint)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        if (has) {
            val l = minOf(x0, x1)
            val t = minOf(y0, y1)
            val r = maxOf(x0, x1)
            val b = maxOf(y0, y1)
            canvas.save()
            canvas.clipRect(l, t, r, b)
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
            canvas.restore()
            canvas.drawRect(l, t, r, b, boxPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                x0 = event.x
                y0 = event.y
                x1 = event.x
                y1 = event.y
                has = true
            }
            MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                x1 = event.x
                y1 = event.y
            }
        }
        invalidate()
        return true
    }

    fun selection(): Rect? {
        if (!has || width == 0 || height == 0) return null
        val sx = bmp.width.toFloat() / width
        val sy = bmp.height.toFloat() / height
        val l = (minOf(x0, x1) * sx).toInt().coerceIn(0, bmp.width)
        val t = (minOf(y0, y1) * sy).toInt().coerceIn(0, bmp.height)
        val r = (maxOf(x0, x1) * sx).toInt().coerceIn(0, bmp.width)
        val b = (maxOf(y0, y1) * sy).toInt().coerceIn(0, bmp.height)
        val rect = Rect(l, t, r, b)
        return if (rect.width() < 4 || rect.height() < 4) null else rect
    }
}
