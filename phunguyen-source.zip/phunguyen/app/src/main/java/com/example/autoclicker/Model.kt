package com.example.autoclicker

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

const val MIN_DELAY_MS = 100L
const val MAX_DELAY_MS = 100_000L

enum class ActionType { TAP, SWIPE }

/**
 * Một thao tác. Toạ độ lưu theo TỶ LỆ màn hình (0..1) để dự án dán sang máy khác
 * (độ phân giải khác) vẫn đặt chấm gần đúng vị trí.
 */
class ClickAction(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var type: ActionType = ActionType.TAP,
    var enabled: Boolean = true,
    var delayMs: Long = 1000L,      // chờ SAU khi thực hiện xong (100 ms .. 100 s)
    var swipeMs: Long = 400L,       // thời gian vuốt
    var x1: Float = 0.5f,           // điểm chạm / điểm bắt đầu vuốt
    var y1: Float = 0.5f,
    var x2: Float = 0.5f,           // điểm kết thúc vuốt
    var y2: Float = 0.3f,
    var image: String? = null,      // PNG xám (đã thu nhỏ chuẩn) mã hoá base64; null = không cần ảnh
    var matchPct: Int = 85,         // độ khớp yêu cầu 50..99
    var tapOnMatch: Boolean = false // bấm vào vị trí tìm thấy ảnh thay vì vị trí chấm
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("type", type.name)
        put("enabled", enabled)
        put("delayMs", delayMs)
        put("swipeMs", swipeMs)
        put("x1", x1.toDouble())
        put("y1", y1.toDouble())
        put("x2", x2.toDouble())
        put("y2", y2.toDouble())
        val img = image
        if (img != null) put("image", img)
        put("matchPct", matchPct)
        put("tapOnMatch", tapOnMatch)
    }

    companion object {
        fun fromJson(o: JSONObject): ClickAction {
            val img = o.optString("image", "")
            return ClickAction(
                id = o.optString("id", "").ifBlank { UUID.randomUUID().toString() },
                name = o.optString("name", ""),
                type = if (o.optString("type", "") == "SWIPE") ActionType.SWIPE else ActionType.TAP,
                enabled = o.optBoolean("enabled", true),
                delayMs = o.optLong("delayMs", 1000L).coerceIn(MIN_DELAY_MS, MAX_DELAY_MS),
                swipeMs = o.optLong("swipeMs", 400L).coerceIn(50L, 10_000L),
                x1 = o.optDouble("x1", 0.5).toFloat().coerceIn(0f, 1f),
                y1 = o.optDouble("y1", 0.5).toFloat().coerceIn(0f, 1f),
                x2 = o.optDouble("x2", 0.5).toFloat().coerceIn(0f, 1f),
                y2 = o.optDouble("y2", 0.3).toFloat().coerceIn(0f, 1f),
                image = if (img.isBlank()) null else img,
                matchPct = o.optInt("matchPct", 85).coerceIn(50, 99),
                tapOnMatch = o.optBoolean("tapOnMatch", false)
            )
        }
    }
}

/** Một dự án = một danh sách thao tác chạy lần lượt và lặp liên tục. */
class Project(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "Dự án mới",
    val actions: MutableList<ClickAction> = mutableListOf()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        val arr = JSONArray()
        for (a in actions) arr.put(a.toJson())
        put("actions", arr)
    }

    companion object {
        private const val MAX_ACTIONS = 500

        fun fromJson(o: JSONObject): Project {
            val p = Project(
                id = o.optString("id", "").ifBlank { UUID.randomUUID().toString() },
                name = o.optString("name", "").ifBlank { "Dự án" }
            )
            val arr = o.optJSONArray("actions")
            if (arr != null) {
                for (i in 0 until minOf(arr.length(), MAX_ACTIONS)) {
                    val ao = arr.optJSONObject(i)
                    if (ao != null) p.actions.add(ClickAction.fromJson(ao))
                }
            }
            return p
        }

        /** Bản sao độc lập (id mới cho dự án và từng thao tác). */
        fun copyOf(src: Project, newName: String): Project {
            val p = fromJson(src.toJson())
            p.id = UUID.randomUUID().toString()
            p.name = newName
            for (a in p.actions) a.id = UUID.randomUUID().toString()
            return p
        }
    }
}

/**
 * Chuyển dự án <-> một chuỗi chữ để Sao chép / Dán giữa các máy.
 * Định dạng: "PHUNGUYEN1:" + Base64(GZIP(JSON)).
 */
object ProjectCodec {
    private const val PREFIX = "PHUNGUYEN1:"
    private const val MAX_TEXT = 6_000_000

    fun encode(p: Project): String {
        val json = p.toJson().toString().toByteArray(Charsets.UTF_8)
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(json) }
        return PREFIX + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    /** Trả về dự án mới (id mới) hoặc null nếu chuỗi không hợp lệ. */
    fun decode(text: String): Project? {
        if (text.length > MAX_TEXT) return null
        val i = text.indexOf(PREFIX)
        if (i < 0) return null
        return try {
            // Bỏ mọi khoảng trắng/xuống dòng do app chat chèn vào khi dán.
            val b64 = text.substring(i + PREFIX.length).filter { !it.isWhitespace() }
            val raw = Base64.decode(b64, Base64.DEFAULT)
            val json = GZIPInputStream(ByteArrayInputStream(raw)).use { it.readBytes() }
            val src = Project.fromJson(JSONObject(String(json, Charsets.UTF_8)))
            Project.copyOf(src, src.name)
        } catch (e: Exception) {
            null
        }
    }
}
