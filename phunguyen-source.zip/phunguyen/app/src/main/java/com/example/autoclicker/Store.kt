package com.example.autoclicker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.io.File

/**
 * Lưu mỗi dự án thành một file JSON trong filesDir/projects.
 * App và dịch vụ trợ năng dùng chung lớp này; khi app sửa xong sẽ gọi touch()
 * để dịch vụ biết mà nạp lại.
 */
class ProjectStore(context: Context) {

    companion object {
        const val KEY_REV = "rev"
        private const val KEY_ACTIVE = "active"
    }

    private val appCtx = context.applicationContext
    val prefs: SharedPreferences = appCtx.getSharedPreferences("phunguyen", Context.MODE_PRIVATE)
    private val dir = File(appCtx.filesDir, "projects").apply { mkdirs() }

    private fun fileOf(id: String) = File(dir, "$id.json")

    fun load(id: String): Project? {
        return try {
            val f = fileOf(id)
            if (!f.exists()) null
            else Project.fromJson(JSONObject(f.readText(Charsets.UTF_8))).also { it.id = id }
        } catch (e: Exception) {
            null
        }
    }

    fun save(p: Project) {
        try {
            val tmp = File(dir, "${p.id}.tmp")
            tmp.writeText(p.toJson().toString(), Charsets.UTF_8)
            if (!tmp.renameTo(fileOf(p.id))) {
                fileOf(p.id).writeText(p.toJson().toString(), Charsets.UTF_8)
                tmp.delete()
            }
        } catch (e: Exception) {
            // bỏ qua: lần lưu sau sẽ thử lại
        }
    }

    fun delete(id: String) {
        fileOf(id).delete()
    }

    fun all(): List<Project> {
        val files = dir.listFiles { f -> f.name.endsWith(".json") } ?: return emptyList()
        return files
            .mapNotNull { f -> load(f.name.removeSuffix(".json")) }
            .sortedBy { it.name.lowercase() }
    }

    fun setActive(id: String) {
        prefs.edit().putString(KEY_ACTIVE, id).apply()
    }

    /** Dự án đang dùng; tự chọn dự án đầu tiên hoặc tạo dự án mới nếu chưa có. */
    fun active(): Project {
        val id = prefs.getString(KEY_ACTIVE, null)
        if (id != null) {
            val p = load(id)
            if (p != null) return p
        }
        val first = all().firstOrNull()
        if (first != null) {
            setActive(first.id)
            return first
        }
        val fresh = Project(name = "Dự án 1")
        save(fresh)
        setActive(fresh.id)
        return fresh
    }

    /** Báo cho dịch vụ trợ năng nạp lại dự án. */
    fun touch() {
        prefs.edit().putLong(KEY_REV, prefs.getLong(KEY_REV, 0L) + 1L).apply()
    }
}
