package com.example.autoclicker

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Nhận diện ảnh không cần OpenCV.
 *
 * - Mọi ảnh chụp màn hình được thu nhỏ (trung bình khối) về cạnh ngắn = CANON_SHORT px
 *   và chuyển sang xám, nên ảnh mẫu chụp ở máy này vẫn dùng được trên máy khác.
 * - So khớp bằng sai lệch tuyệt đối trung bình đã trừ độ sáng trung bình (chịu được
 *   ngày/đêm đổi sáng trong game), quét thô (từng pixel, lấy mẫu thưa, dừng sớm) rồi tinh chỉnh.
 */
object Matcher {
    const val CANON_SHORT = 400
    const val MAX_TPL = 240

    class Gray(val w: Int, val h: Int, val px: IntArray)

    class Hit(val x: Int, val y: Int, val score: Float)

    fun scaleFor(w: Int, h: Int): Float = CANON_SHORT.toFloat() / minOf(w, h).toFloat()

    /** Bitmap phần mềm ARGB_8888 -> ảnh xám cỡ chuẩn. */
    fun toCanonGray(src: Bitmap): Gray {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val s = scaleFor(w, h)
        val tw = maxOf(1, (w * s).roundToInt())
        val th = maxOf(1, (h * s).roundToInt())
        val out = IntArray(tw * th)
        for (ty in 0 until th) {
            val y0 = ty * h / th
            val y1 = maxOf(y0 + 1, (ty + 1) * h / th)
            for (tx in 0 until tw) {
                val x0 = tx * w / tw
                val x1 = maxOf(x0 + 1, (tx + 1) * w / tw)
                var sum = 0
                for (yy in y0 until y1) {
                    var i = yy * w + x0
                    for (xx in x0 until x1) {
                        val c = px[i++]
                        sum += (((c shr 16) and 255) * 77 + ((c shr 8) and 255) * 151 + (c and 255) * 28) shr 8
                    }
                }
                out[ty * tw + tx] = sum / ((y1 - y0) * (x1 - x0))
            }
        }
        return Gray(tw, th, out)
    }

    /** Cắt vùng (toạ độ pixel của ảnh chụp) thành ảnh mẫu cỡ chuẩn; null nếu quá nhỏ. */
    fun cropTemplate(src: Bitmap, l: Int, t: Int, r: Int, b: Int): Gray? {
        val g = toCanonGray(src)
        val s = scaleFor(src.width, src.height)
        val x0 = (l * s).roundToInt().coerceIn(0, g.w - 1)
        val y0 = (t * s).roundToInt().coerceIn(0, g.h - 1)
        val x1 = (r * s).roundToInt().coerceIn(x0, g.w)
        val y1 = (b * s).roundToInt().coerceIn(y0, g.h)
        val w = x1 - x0
        val h = y1 - y0
        if (w < 8 || h < 8) return null
        val out = IntArray(w * h)
        for (y in 0 until h) {
            System.arraycopy(g.px, (y0 + y) * g.w + x0, out, y * w, w)
        }
        return Gray(w, h, out)
    }

    /** Độ tương phản (lệch tuyệt đối trung bình quanh mức sáng trung bình). */
    fun contrast(g: Gray): Float {
        var sum = 0L
        for (v in g.px) sum += v
        val mean = sum.toFloat() / g.px.size
        var d = 0f
        for (v in g.px) {
            val e = v - mean
            d += if (e < 0) -e else e
        }
        return d / g.px.size
    }

    fun encode(g: Gray): String {
        val bmp = Bitmap.createBitmap(g.w, g.h, Bitmap.Config.ARGB_8888)
        val px = IntArray(g.px.size)
        for (i in px.indices) {
            val v = g.px[i]
            px[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        bmp.setPixels(px, 0, g.w, 0, 0, g.w, g.h)
        val bos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
        bmp.recycle()
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    fun decode(b64: String): Gray? {
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val w = bmp.width
            val h = bmp.height
            if (w < 1 || h < 1 || w > 4 * MAX_TPL || h > 4 * MAX_TPL) {
                bmp.recycle()
                return null
            }
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            bmp.recycle()
            for (i in px.indices) px[i] = px[i] and 255
            Gray(w, h, px)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Tìm ảnh mẫu trong cảnh. Trả về tâm ảnh (pixel màn hình thật) nếu độ khớp đạt yêu cầu.
     * screenW/screenH là kích thước ảnh chụp gốc.
     */
    fun locate(scene: Gray, tpl: Gray, matchPct: Int, screenW: Int, screenH: Int): PointF? {
        val hit = find(scene, tpl) ?: return null
        val maxMad = (100 - matchPct.coerceIn(50, 99)) * 1.2f
        if (hit.score > maxMad) return null
        val s = scaleFor(screenW, screenH)
        return PointF((hit.x + tpl.w / 2f) / s, (hit.y + tpl.h / 2f) / s)
    }

    /** Vị trí (góc trên trái, toạ độ chuẩn) có sai lệch nhỏ nhất và điểm sai lệch. */
    fun find(scene: Gray, tpl: Gray): Hit? {
        val sw = scene.w
        val sh = scene.h
        val tw = tpl.w
        val th = tpl.h
        if (tw > sw || th > sh) return null
        val sp = scene.px
        val tp = tpl.px

        // Ảnh tích phân để lấy độ sáng trung bình của từng vùng trong O(1).
        val iw = sw + 1
        val integ = IntArray(iw * (sh + 1))
        for (y in 0 until sh) {
            var row = 0
            val base = (y + 1) * iw
            val prev = y * iw
            for (x in 0 until sw) {
                row += sp[y * sw + x]
                integ[base + x + 1] = integ[prev + x + 1] + row
            }
        }
        var tsum = 0L
        for (v in tp) tsum += v
        val area = (tw * th).toFloat()
        val tmean = tsum.toFloat() / area

        // Điểm lấy mẫu thưa (~200 điểm) cho lượt quét thô.
        val step = maxOf(1, ceil(sqrt(tw.toDouble() * th / 200.0)).toInt())
        val cnt = ((th + step - 1) / step) * ((tw + step - 1) / step)
        val offs = IntArray(cnt)
        val vals = IntArray(cnt)
        var k = 0
        var yy = 0
        while (yy < th) {
            var xx = 0
            while (xx < tw) {
                offs[k] = yy * sw + xx
                vals[k] = tp[yy * tw + xx]
                k++
                xx += step
            }
            yy += step
        }

        val maxX = sw - tw
        val maxY = sh - th
        var best = Float.MAX_VALUE
        var bx = 0
        var by = 0
        var oy = 0
        while (oy <= maxY) {
            var ox = 0
            while (ox <= maxX) {
                val s = integ[(oy + th) * iw + ox + tw] - integ[oy * iw + ox + tw] -
                    integ[(oy + th) * iw + ox] + integ[oy * iw + ox]
                val off = s / area - tmean
                val baseIdx = oy * sw + ox
                var sum = 0f
                var j = 0
                while (j < cnt) {
                    val d = sp[baseIdx + offs[j]] - vals[j] - off
                    sum += if (d < 0f) -d else d
                    if (sum >= best) break
                    j++
                }
                if (j == cnt && sum < best) {
                    best = sum
                    bx = ox
                    by = oy
                }
                ox++
            }
            oy++
        }
        if (best == Float.MAX_VALUE) return null

        // Tinh chỉnh quanh ứng viên tốt nhất bằng so khớp đầy đủ mọi điểm ảnh.
        var rb = Float.MAX_VALUE
        var rx = bx
        var ry = by
        for (cy in maxOf(0, by - 2)..minOf(maxY, by + 2)) {
            for (cx in maxOf(0, bx - 2)..minOf(maxX, bx + 2)) {
                val s = integ[(cy + th) * iw + cx + tw] - integ[cy * iw + cx + tw] -
                    integ[(cy + th) * iw + cx] + integ[cy * iw + cx]
                val off = s / area - tmean
                var sum = 0f
                for (ty in 0 until th) {
                    val rowS = (cy + ty) * sw + cx
                    val rowT = ty * tw
                    for (tx in 0 until tw) {
                        val d = sp[rowS + tx] - tp[rowT + tx] - off
                        sum += if (d < 0f) -d else d
                    }
                }
                if (sum < rb) {
                    rb = sum
                    rx = cx
                    ry = cy
                }
            }
        }
        return Hit(rx, ry, rb / area)
    }
}

/** Giải mã ảnh mẫu một lần cho mỗi thao tác. */
object TemplateCache {
    private val map = HashMap<String, Pair<String, Matcher.Gray>>()

    @Synchronized
    fun get(a: ClickAction): Matcher.Gray? {
        val img = a.image ?: return null
        val cached = map[a.id]
        if (cached != null && cached.first == img) return cached.second
        val g = Matcher.decode(img) ?: return null
        map[a.id] = Pair(img, g)
        return g
    }
}
