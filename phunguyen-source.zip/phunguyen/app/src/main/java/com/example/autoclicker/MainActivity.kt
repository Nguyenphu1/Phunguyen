package com.example.autoclicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private companion object {
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var store: ProjectStore
    private lateinit var project: Project
    private lateinit var content: LinearLayout
    private var dirty = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProjectStore(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(content) })
    }

    override fun onResume() {
        super.onResume()
        project = store.active()
        dirty = false
        render()
    }

    override fun onPause() {
        flush()
        super.onPause()
    }

    // ------------------------------------------------------------------ lưu

    private fun changed() {
        dirty = true
    }

    /** Ghi xuống đĩa và báo dịch vụ nạp lại (chỉ khi có thay đổi). */
    private fun flush() {
        if (dirty && ::project.isInitialized) {
            store.save(project)
            store.touch()
            dirty = false
        }
    }

    private fun commitNow() {
        dirty = true
        flush()
    }

    private fun switchTo(p: Project) {
        store.save(p)
        store.setActive(p.id)
        store.touch()
        project = p
        dirty = false
        render()
    }

    // ------------------------------------------------------------------ vẽ giao diện

    private fun render() {
        content.removeAllViews()

        content.addView(TextView(this).apply {
            text = "phunguyen"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Tự động chạm / vuốt cho nông trại Play Together"
            textSize = 13f
        })

        addProjectBar()
        addShareBar()
        addServiceStatus()

        content.addView(caption("Thao tác (chạy lần lượt theo thứ tự rồi lặp lại)"))
        if (project.actions.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Chưa có thao tác nào. Bấm \"Thêm thao tác\" bên dưới."
            })
        }
        project.actions.forEachIndexed { i, a -> content.addView(actionCard(a, i)) }

        content.addView(Button(this).apply {
            text = "➕ Thêm thao tác"
            setOnClickListener { addAction() }
        })

        content.addView(TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(20), 0, 0)
            text = "Cách dùng:\n" +
                "1. Thêm thao tác (Chạm hoặc Vuốt), đặt thời gian chờ 100 ms – 100 000 ms cho từng thao tác.\n" +
                "2. Bấm \"Mở cài đặt Trợ năng\" và bật dịch vụ phunguyen.\n" +
                "3. Mở game. Trên bảng nổi, tick các thao tác muốn chạy rồi kéo mỗi chấm số tới đúng nút trong game " +
                "(thao tác Vuốt có 2 chấm: bắt đầu \"n\" và kết thúc \"→n\").\n" +
                "4. Muốn thao tác chỉ chạy khi thấy một hình: bấm 📷 cạnh thao tác trên bảng nổi rồi khoanh vùng hình " +
                "(cần Android 11+). Không thấy hình thì thao tác bị bỏ qua.\n" +
                "5. Bấm ▶ Bắt đầu. Bấm ■ Dừng để dừng.\n\n" +
                "Chép sang máy khác: bấm Sao chép ở đây, gửi đoạn chữ qua tin nhắn, rồi trên máy kia bấm Dán. " +
                "Vị trí chấm lưu theo tỷ lệ màn hình nên khớp gần đúng; nếu lệch thì kéo lại chấm."
        })
    }

    private fun addProjectBar() {
        content.addView(caption("Dự án"))
        val all = store.all()
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, all.map { it.name })
        spinner.setSelection(all.indexOfFirst { it.id == project.id }.coerceAtLeast(0), false)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val target = all.getOrNull(position) ?: return
                if (target.id != project.id) {
                    flush()
                    store.setActive(target.id)
                    store.touch()
                    project = target
                    dirty = false
                    content.post { render() }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        content.addView(spinner)

        content.addView(buttonRow(
            smallBtn("➕ Mới") {
                askText("Tên dự án mới", "") { name ->
                    flush()
                    switchTo(Project(name = name.ifBlank { "Dự án mới" }))
                }
            },
            smallBtn("⧉ Nhân bản") {
                flush()
                switchTo(Project.copyOf(project, project.name + " (bản sao)"))
            },
            smallBtn("✎ Đổi tên") {
                askText("Đổi tên dự án", project.name) { name ->
                    if (name.isNotBlank()) {
                        project.name = name
                        commitNow()
                        render()
                    }
                }
            },
            smallBtn("🗑 Xóa") { confirmDeleteProject() }
        ))
    }

    private fun addShareBar() {
        content.addView(buttonRow(
            smallBtn("📋 Sao chép") { copyProject() },
            smallBtn("📥 Dán") { pasteProject() },
            smallBtn("📤 Chia sẻ") { shareProject() }
        ))
    }

    private fun addServiceStatus() {
        val on = isServiceEnabled()
        content.addView(TextView(this).apply {
            text = if (on) "● Dịch vụ trợ năng: ĐANG BẬT" else "○ Dịch vụ trợ năng: chưa bật"
            setTextColor(if (on) Color.rgb(0, 150, 0) else Color.rgb(200, 60, 60))
            setPadding(0, dp(12), 0, dp(4))
        })
        content.addView(Button(this).apply {
            text = "Mở cài đặt Trợ năng"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
    }

    private fun actionCard(a: ClickAction, i: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), Color.GRAY)
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        }

        // Hàng 1: bật/tắt, tên, sắp xếp, xóa
        val r1 = hRow()
        r1.addView(CheckBox(this).apply {
            text = "${i + 1}"
            isChecked = a.enabled
            setOnCheckedChangeListener { _, on ->
                a.enabled = on
                changed()
            }
        })
        r1.addView(EditText(this).apply {
            hint = "Tên"
            setText(a.name)
            setSingleLine(true)
            doAfterTextChanged {
                a.name = it?.toString().orEmpty()
                changed()
            }
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        r1.addView(smallBtn("▲") { moveAction(i, -1) })
        r1.addView(smallBtn("▼") { moveAction(i, 1) })
        r1.addView(smallBtn("✕") { confirmDeleteAction(a) })
        card.addView(r1)

        // Hàng 2: loại + thời gian chờ
        val r2 = hRow()
        val typeSpinner = Spinner(this)
        typeSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, listOf("Chạm", "Vuốt")
        )
        typeSpinner.setSelection(if (a.type == ActionType.SWIPE) 1 else 0, false)
        typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val t = if (position == 1) ActionType.SWIPE else ActionType.TAP
                if (t != a.type) {
                    a.type = t
                    commitNow()
                    content.post { render() }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        r2.addView(typeSpinner)
        r2.addView(TextView(this).apply { text = "  Chờ (ms): " })
        r2.addView(numberEdit(a.delayMs.toString()) { v ->
            a.delayMs = v.coerceIn(MIN_DELAY_MS, MAX_DELAY_MS)
            changed()
        }, LinearLayout.LayoutParams(dp(100), WRAP))
        card.addView(r2)

        // Hàng 3 (chỉ Vuốt): thời gian vuốt
        if (a.type == ActionType.SWIPE) {
            val r3 = hRow()
            r3.addView(TextView(this).apply { text = "Thời gian vuốt (ms): " })
            r3.addView(numberEdit(a.swipeMs.toString()) { v ->
                a.swipeMs = v.coerceIn(50L, 10_000L)
                changed()
            }, LinearLayout.LayoutParams(dp(100), WRAP))
            card.addView(r3)
        }

        // Ảnh nhận diện
        val img = a.image
        card.addView(TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(6), 0, 0)
            text = if (img == null) {
                "Ảnh nhận diện: chưa có → luôn thực hiện. Muốn thêm, mở game và bấm 📷 trên bảng nổi (Android 11+)."
            } else {
                "Ảnh nhận diện: đã có (~${img.length * 3 / 4 / 1024 + 1} KB) → chỉ thực hiện khi thấy ảnh trên màn hình."
            }
        })
        if (img != null) {
            val r4 = hRow()
            r4.addView(smallBtn("Xóa ảnh") {
                a.image = null
                commitNow()
                render()
            })
            r4.addView(TextView(this).apply { text = "  Độ khớp (%): " })
            r4.addView(numberEdit(a.matchPct.toString()) { v ->
                a.matchPct = v.coerceIn(50L, 99L).toInt()
                changed()
            }, LinearLayout.LayoutParams(dp(64), WRAP))
            card.addView(r4)
            if (a.type == ActionType.TAP) {
                card.addView(CheckBox(this).apply {
                    text = "Bấm vào đúng vị trí tìm thấy ảnh"
                    isChecked = a.tapOnMatch
                    setOnCheckedChangeListener { _, on ->
                        a.tapOnMatch = on
                        changed()
                    }
                })
            }
        }
        return card
    }

    // ------------------------------------------------------------------ thao tác trên danh sách

    private fun addAction() {
        val n = project.actions.size
        val x = 0.15f + 0.1f * (n % 7)
        project.actions.add(
            ClickAction(name = "Thao tác ${n + 1}", x1 = x, y1 = 0.6f, x2 = x, y2 = 0.4f)
        )
        commitNow()
        render()
    }

    private fun moveAction(i: Int, dir: Int) {
        val j = i + dir
        if (j < 0 || j >= project.actions.size) return
        Collections.swap(project.actions, i, j)
        commitNow()
        render()
    }

    private fun confirmDeleteAction(a: ClickAction) {
        AlertDialog.Builder(this)
            .setTitle("Xóa thao tác?")
            .setMessage(if (a.name.isBlank()) "Thao tác này sẽ bị xóa." else "Xóa \"${a.name}\"?")
            .setPositiveButton("Xóa") { _, _ ->
                project.actions.remove(a)
                commitNow()
                render()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun confirmDeleteProject() {
        AlertDialog.Builder(this)
            .setTitle("Xóa dự án?")
            .setMessage("Xóa \"${project.name}\" cùng toàn bộ thao tác của nó?")
            .setPositiveButton("Xóa") { _, _ ->
                store.delete(project.id)
                project = store.active()   // tự chọn dự án khác hoặc tạo dự án trống
                dirty = false
                store.touch()
                render()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    // ------------------------------------------------------------------ sao chép / dán / chia sẻ

    private fun copyProject() {
        flush()
        val text = ProjectCodec.encode(project)
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        try {
            cm.setPrimaryClip(ClipData.newPlainText("phunguyen", text))
            toast("Đã sao chép dự án (${text.length / 1024 + 1} KB). Trên máy khác, mở phunguyen và bấm Dán.")
        } catch (e: Exception) {
            toast("Không sao chép được (dự án quá lớn). Hãy dùng Chia sẻ.")
        }
    }

    private fun pasteProject() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else {
            null
        }
        val imported = if (text != null) ProjectCodec.decode(text) else null
        if (imported == null) {
            toast("Clipboard không có dự án phunguyen hợp lệ")
            return
        }
        flush()
        switchTo(imported)
        toast("Đã nhập dự án: ${imported.name}")
    }

    private fun shareProject() {
        flush()
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, ProjectCodec.encode(project))
        }
        startActivity(Intent.createChooser(send, "Chia sẻ dự án"))
    }

    // ------------------------------------------------------------------ tiện ích giao diện

    private fun isServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    private fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(initial)
            setSingleLine(true)
            setSelection(initial.length)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> onOk(input.text.toString().trim()) }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun caption(t: String) = TextView(this).apply {
        text = t
        textSize = 15f
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun hRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun buttonRow(vararg buttons: Button): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (b in buttons) row.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    private fun smallBtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setAllCaps(false)
        textSize = 13f
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { onClick() }
    }

    /** Ô nhập số; onValue chỉ được gọi khi nội dung là số hợp lệ. */
    private fun numberEdit(initial: String, onValue: (Long) -> Unit) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setSingleLine(true)
        setText(initial)
        doAfterTextChanged {
            val v = it?.toString()?.toLongOrNull()
            if (v != null) onValue(v)
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
